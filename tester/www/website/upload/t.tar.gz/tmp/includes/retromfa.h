#ifndef RETROMFA
#define RETROMFA

#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "mlx.h"
#include <string.h>
#include <X11/X.h>
#include <X11/keysym.h>
#include <math.h>
#define NB_PATTERN 2
#define PATTERN_SIZE 4

const unsigned char patterns[NB_PATTERN][PATTERN_SIZE] = {{0, 6, 16, 0}, {0, 4, 16, 0}};



typedef struct s_color
{
    int r;
    int g;
    int b;
    int rgb;
} t_color;

typedef struct s_img
{
    void *mlx_img;
    char *addr;
    int bpp;
    int line_len;
    int endian;
    int w;
    int h;
} t_img;

typedef struct s_data
{
    void *win_ptr;
    void *mlx_ptr;
    t_img img;
    char *buf;
    int size;
    int w;
    int h;
    int byte_off;
    char *p;
    int width;
    int height;
    int conv;
    // int w_off;
    // int h_off;
} t_data;

void *ft_print_memory(void *addr, unsigned int size);
char *searchPattern(t_data *d, char *buf, const unsigned char *pattern, int n);
char *searchPatterns(t_data *d, char *buf, int n);

#endif