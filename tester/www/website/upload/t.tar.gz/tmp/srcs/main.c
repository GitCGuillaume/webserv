#include "retromfa.h"
#define HEIGHT 800
#define WIDTH 800

long int findSize(char file_name[])
{
    // opening the file in read mode
    FILE *fp = fopen(file_name, "r");

    // checking if the file exist or not
    if (fp == NULL)
    {
        printf("File Not Found!\n");
        return -1;
    }
    fseek(fp, 0L, SEEK_END);
    // calculating the size of the file
    long int res = ftell(fp);

    // closing the file
    fclose(fp);

    return res;
}

void free_data(t_data *d)
{
    if (d->win_ptr)
        mlx_destroy_window(d->mlx_ptr, d->win_ptr);
    if (d->img.mlx_img)
        mlx_destroy_image(d->mlx_ptr, d->img.mlx_img);
    mlx_destroy_display(d->mlx_ptr);
    free(d->mlx_ptr);
}

void print_err(const char *err_msg, t_data *d)
{
    fprintf(stderr, "%s\n", err_msg);
    free_data(d);
    exit(EXIT_FAILURE);
}

int handle_exit(t_data *data)
{
    mlx_destroy_window(data->mlx_ptr, data->win_ptr);
    data->win_ptr = NULL;
    return (0);
}

void img_pix_put(t_data *d, int x, int y, int color)
{
    char *pixel;

    pixel = d->img.addr + (y * d->img.line_len + x * (d->img.bpp / 8));
    *(unsigned int *)pixel = color;
}

int getpixelcolor(t_img *img, int x, int y)
{
    return (*(unsigned int *)(img->addr + x * (img->bpp / 8) + y * img->line_len));
}

int encode_rgb(t_color c)
{
    return (c.r << 16 | c.g << 8 | c.b);
}

void draw_img(t_data *d)
{
    // for (int i = 0; i < d->h ; ++i)
    // {
    //     for (int j = 0; j < d->w; ++j)
    //     {
    //         int color = *(unsigned int *)(d->buf + j * 3 + i * d->w * 3 + d->byte_off);
    //         img_pix_put(d, j, i, color);
    //     }
    // }
    for (int i = 0; i < d->height; ++i)
    {
        for (int j = 0; j < d->width; ++j)
        {
            unsigned short color = *(unsigned short *)(d->p + j * 2 + i * d->width * 2);
            int r = color >> 10;
            int g = (color >> 5) & 0x1f;
            int b = color & 0x1f;

            r <<= 3;
            g <<= 3;
            b <<= 3;

            img_pix_put(d, j, i, encode_rgb((t_color){r, g, b, 0}));
            // img_pix_put(d, j, i, *(unsigned int *)(d->p + j * 3 + i * d->width * 3));
        }
    }
}

int render_frame(t_data *d)
{
    bzero(d->img.addr, d->img.line_len * HEIGHT);
    draw_img(d);
    if (d->win_ptr == NULL)
        return (1);
    mlx_put_image_to_window(d->mlx_ptr, d->win_ptr, d->img.mlx_img, 0, 0);
    // img_pix_put(d, 10, 10, encode_rgb((t_color){255, 255, 255, 0}));
    return (0);
}

int handle_keypress(int keysym, t_data *data)
{
    if (keysym == XK_Escape)
    {
        mlx_destroy_window(data->mlx_ptr, data->win_ptr);
        data->win_ptr = NULL;
    }
    else if (keysym == XK_Right)
        data->w++;
    else if (keysym == XK_Left)
        data->w--;
    else if (keysym == XK_Up)
    {
        data->h++;
    }
    else if (keysym == XK_Down)
    {
        data->h--;
    }
    else if (keysym == XK_a)
    {
        data->byte_off--;
    }
    else if (keysym == XK_d)
    {
        data->byte_off++;
    }
    else if (keysym == XK_p)
    {
        unsigned char pattern[4] = {0, 6, 16, 0};

        data->p = searchPattern(data, data->buf + (data->p - data->buf) + 1, pattern, 4);
        data->height = *(unsigned char *)(data->p - 1);
        data->width = *(unsigned char *)(data->p - 3);
        data->p += 17;
    }
    return (0);
}

void read_mfa(char *name)
{
    // FILE *ptr;
    // char ch;
    // ptr = fopen(name, "r");

    // if (NULL == ptr)
    // {
    //     printf("file can't be opened \n");
    // }

    // printf("content of this file are \n");

    // while (!feof(ptr))
    // {
    //     ch = fgetc(ptr);
    //     printf("%c", ch);
    // }
    // fclose(ptr);
    long size = findSize(name);
    long pixel = size / 4;
    printf("size of file %ld bytes\n", size);
    printf("number of pixel %ld\n", pixel);

    printf("sqrt of pixel %f\n", sqrt(pixel));
    char buf[10000];
    int fd = open(name, O_RDONLY);
    read(fd, buf, 10000);
    ft_print_memory(buf, 10000);
}
void print_img_data(t_img *i)
{
    printf("bit per pixel %d\n", i->bpp);
    printf("endian %d\n", i->endian);
    printf("line_len %d\n", i->line_len);
}
void print_title(int fd)
{
    int x;
    read(fd, &x, 4); // mfa magic number
    printf("x %d\n", x);
    read(fd, &x, 4); // mfa magic number
    printf("x %d\n", x);
    read(fd, &x, 4); // mfa magic number
    printf("x %d\n", x);
    read(fd, &x, 4); // mfa magic number
    printf("x %d\n", x);

    {
        int title_len;
        read(fd, &title_len, 4);
        char *title = malloc(title_len + 1);
        title[title_len] = 0;
        read(fd, title, title_len);
        printf("title - len %d : %s\n", title_len, title);
        free(title);
    }

    {
        int something;
        read(fd, &something, 4);
        char *title = malloc(something + 1);
        title[something] = 0;
        read(fd, title, something);
        printf("sub-title - len %d : %s\n", something, title);
        free(title);
    }
    {
        int something;
        read(fd, &something, 4);
        char *title = malloc(something + 1);
        title[something] = 0;
        read(fd, title, something);
        printf("info - len %d : %s\n", something, title);
        free(title);
    }
}

int print_info(char *name)
{
    //    printf("Little endian");
    //    getchar();
    long size = findSize(name);
    long pixel = size / 4;
    int width = (int)sqrt(pixel);

    printf("size of file %ld bytes\n", size);
    printf("number of pixel %ld\n", pixel);
    printf("sqrt of pixel %f\n", sqrt(pixel));

    return size;
}
char *searchPatterns(t_data *d, char *buf, int n)
{
    for (int i = 0 ; i<NB_PATTERN; i++) {
        char *res = searchPattern(d, buf, patterns[i], n);
        if (res)
            return(res);
    }
    return NULL;
}


char *searchPattern(t_data *d, char *buf, const unsigned char *pattern, int n)
{
    for (int i = 0; i < d->size - n; i++)
    {
        int j = 0;
        while (j < n && ((buf))[i + j] == pattern[j])
        {
            j++;
        }
        if (j == n && i - 1 > 0 && buf[i - 1] != 0 && i - 3 > 0 && buf[i - 3] != 0)
        {
            // printf("i %d\n", i);
            return (buf + i);
        }
    }
    return NULL;
}

int main(int argc, char **argv)
{

    if (argc != 2)
    {
        printf("Error: Usage: ./retromfa {filename}.mfa\n");
        return 1;
    }

    int fd = open(argv[1], O_RDONLY);
    if (fd < 0 || read(fd, 0, 0))
    {
        printf("Error: Cannot open file.");
        return 1;
    }

    t_data d;
    bzero(&d, sizeof(d));


    // print_title(fd);
    d.size = print_info(argv[1]);
    d.buf = (char *)malloc(d.size);

    d.w = WIDTH;
    d.h = HEIGHT;

    // int nums[14];
    // for (int i = 0; i < 14; i++)
    // {
    //     read(fd, &nums[i], 4);
    //     printf("%d : %d - %d\n", i + 1, lseek(fd, 0, SEEK_CUR), nums[i]);
    // }
    // int pixels = (nums[0] - 56);

    /* mlx init()*/ {
        d.mlx_ptr = mlx_init();
        d.win_ptr = mlx_new_window(d.mlx_ptr, d.w, d.h, "retromfa");
        if (!d.win_ptr)
            print_err("Failed to launch window.", &d);
        d.img.mlx_img = mlx_new_image(d.mlx_ptr, d.w, d.h);
        if (!d.img.mlx_img)
            print_err("mlx new image error", &d);
        d.img.addr = mlx_get_data_addr(d.img.mlx_img, &d.img.bpp,
                                       &d.img.line_len, &d.img.endian);
    }
    read(fd, d.buf, d.size);


    d.p = searchPattern(&d, d.buf, pattern, 4);
    printf("offset %ld\n", d.p - d.buf);
    // d.byte_off = d.p - d.buf;
    d.height = *(unsigned char *)(d.p - 1);
    d.width = *(unsigned char *)(d.p - 3);
    d.p += 17;
    printf("height %d width %d\n", d.height, d.width);

    print_img_data(&d.img);
    // char buf[10000];

    // read(fd, buf, nums[0]);
    // for (int i = 0; i < 40; ++i)
    // {
    //     for (int j = 0; j < pixels / 40; ++j)
    //     {
    //         int color;
    //         read(fd, &color, 4);
    //         // printf("%d - %d\n", lseek(fd, 0, SEEK_CUR), color);
    //         img_pix_put(&d, j, i, color);
    //     }
    // }

    // read(fd, d.img.addr, size);
    //  ft_print_memory(d.img.addr, size);
    mlx_loop_hook(d.mlx_ptr, render_frame, &d);
    mlx_hook(d.win_ptr, KeyPress, KeyPressMask, &handle_keypress, &d);
    mlx_hook(d.win_ptr, ClientMessage,
             StructureNotifyMask, &handle_exit, &d);
    mlx_loop(d.mlx_ptr);
    free_data(&d);
    close(fd);
    return (0);
}

// size_t something;
// read(fd, &something, 4);
// printf("here something %u\n", something);
// read(fd, &something, 4);
// printf("here something %u\n", something);

// while(read(fd, &something, 4) > 0)
// {

//     printf("here something %u\n", something);
//     char *title = malloc(something + 1);
//     bzero(title, something + 1);
//     read(fd, title, something);
//     title[something] = 0;
//     printf("title %s\n", title);
//     free(title);
// }

// int fd2 = open("MFA/brown.mfa", O_RDONLY);
// test(fd2);

// int something = 0;
// int something2 = 0;
// read(fd, &something, 4);
// read(fd2, &something2, 4);
// printf("something %d\n", something);

// // print ^
// int same = 0;
// while (same < 14)
// {
//     read(fd, &something, 4);
//     read(fd2, &something2, 4);
//     //printf("fd something %d\n", something);
//     same++;
//     //printf("fd something2 %d\n", something2);
//     // char *title = malloc(something + 1);
//     // title[something] = 0;
//     // read(fd, title, something);
//     // printf("title %s\n", title);
// }
// printf("same %d\n", same);
// read(fd, &something, 4);
// printf("something %u\n", something);