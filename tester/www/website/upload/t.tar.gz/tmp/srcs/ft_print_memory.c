#include "retromfa.h"

void	convert_base_int(unsigned int c, char *base, int base_len, int len)
{
	if (len == 1)
	{
		write(1, &base[c], 1);
		return ;
	}
	convert_base_int(c / base_len, base, base_len, len - 1);
	write(1, len == 8 ? "1" : &base[c % base_len], 1);
}

void	ft_putstr_non_printable(char *str, unsigned int size)
{
	unsigned int j;

	j = 0;
	while (j < size)
	{
		write(1, (str[j] < ' ' || str[j] == 127) ? "." : &str[j], 1);
		j++;
	}
}

void	print_hex_data(char *addr, unsigned int size)
{
	unsigned int i;

	i = 0;
	while (i < size)
	{
		convert_base_int((unsigned char)addr[i], "0123456789abcdef", 16, 2);
		if (i % 2 == 1)
			write(1, " ", 1);
		i++;
	}
	while (i < 16)
	{
		ft_putstr_non_printable("  ", 2);
		if (i % 2 == 1)
			write(1, " ", 1);
		i++;
	}
}

void	*ft_print_memory(void *addr, unsigned int size)
{
	unsigned int i;

	i = 0;
	while (i < size)
	{
		convert_base_int((unsigned int)(addr + i), "0123456789abcdef", 16, 16);
		ft_putstr_non_printable(": ", 2);
		print_hex_data(addr + i, (size - i) < 16 ? size - i : 16);
		ft_putstr_non_printable(addr + i, (size - i) < 16 ? size - i : 16);
		write(1, "\n", 1);
		i += 16;
	}
	return (addr);
}
